---
name: Obsidian Crimson
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e5bdbe'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ac8889'
  outline-variant: '#5c3f40'
  surface-tint: '#ffb3b6'
  primary: '#ffb3b6'
  on-primary: '#68001a'
  primary-container: '#e11d48'
  on-primary-container: '#fffaf9'
  inverse-primary: '#be0037'
  secondary: '#ffb3ad'
  on-secondary: '#68000a'
  secondary-container: '#a40217'
  on-secondary-container: '#ffaea8'
  tertiary: '#ffb4ac'
  on-tertiary: '#690007'
  tertiary-container: '#ce423c'
  on-tertiary-container: '#fffaf9'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b6'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#920028'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ad'
  on-secondary-fixed: '#410004'
  on-secondary-fixed-variant: '#930013'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ac'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#8e1214'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.02em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-mono-tag:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system embodies an ultra-focused, high-precision instrument for elite technical workflows, prompt architecture, and deep generative synthesis. The aesthetic reflects austere modern elegance: pitch-black depth punctuated by razor-sharp white clarity and disciplined crimson tension. 

Targeted at AI researchers, senior machine learning engineers, and advanced power users on mobile devices, the interface strips away decorative superficiality to present pure computational signal. It draws from minimalist precision and high-contrast technical utilitarianism, projecting quiet confidence, unmatched computing power, and relentless discipline.

## Colors

The palette establishes an uncompromising dark-mode baseline engineered to eliminate visual fatigue while accentuating data hierarchy.

### Core Hierarchy
- **Canvas Root (`#09090b`)**: Absolute void base layer, maximizing screen contrast and hardware battery efficiency on OLED displays.
- **Surface Elevation 1 (`#121214`)**: Recessed modules, conversation streams, and underlying structural cards.
- **Surface Elevation 2 (`#18181b`)**: Interactive inputs, command sheets, and floating toolbars.
- **Structural Stroke (`#27272a`)**: Ultra-thin precision boundaries delimiting contextual boundaries without visual weight.
- **Primary Accent (`#e11d48`)**: High-chroma crimson reserved for active execution, context pinning, primary catalysts, and system triggers.
- **Secondary Alert (`#ef4444`)**: Ruby red reserved for run halts, critical parameter warnings, and high-priority anomalies.
- **Tertiary Accent (`#991b1b`)**: Subdued deep wine tint used for subtle badge outlines, active parameter tracks, and state indicators.
- **Typographic Neutral High (`#f4f4f5`)**: Pristine crisp white for primary headers, direct inputs, and token outputs.
- **Typographic Neutral Mid (`#a1a1aa`)**: Slate gray for system metadata, inference parameters, and interface prompts.
- **Typographic Neutral Low (`#52525b`)**: Low-emphasis timestamps, inactive token counts, and structural guidance text.

## Typography

Typography prioritizes extreme micro-legibility and structural differentiation. Inter handles human prose, natural language chat bubbles, and modal headers with geometric neutrality and tight negative tracking. 

JetBrains Mono delivers raw technical feedback: tokens-per-second, temperature metrics, prompt context windows, syntax blocks, and raw JSON representations. Code blocks and metadata must maintain strict tabular figures to prevent jitter during streaming inference.

## Layout & Spacing

The layout is built around mobile-first utility, scaling across 1-column responsive single-handed zones up to larger multi-column inspector split screens.

- **Mobile Viewport (< 640px)**: 1-column fluid stacking, anchored bottom command palette, strict 16px horizontal margins (`margin`), and 12px structural gutters (`gutter`). Maximum interaction targets are kept within standard vertical reach zones.
- **Tablet / Desktop Viewport (≥ 640px)**: Fluid multi-pane split. The main conversation canvas is constrained to an optimal reading width (max 768px centered), flanked by a collapsible context/inspector sidebar running a 12-column sub-grid with 20px gutters (`gutter-desktop`).
- **Vertical Rhythm**: Built upon a strict 4px sub-pixel foundation. Component padding and token gaps scale dynamically between `space-xs` (4px micro-tags), `space-sm` (8px token pills and inputs), `space-md` (12px card interiors), and `space-xl` (24px structural section divides).

## Elevation & Depth

Visual hierarchy is maintained without heavy skeuomorphic drop shadows. Depth relies exclusively on calibrated surface tiers, hairline borders, and subtle crimson glow rings:

- **Base Void (`#09090b`)**: Ground tier. Contains passive canvas regions and dead space.
- **Panel Elevation (`#121214`)**: Elevated with a 1px border stroke (`#27272a`). Used for inference threads, assistant message responses, and token stats.
- **Interactive Tier (`#18181b`)**: Active user inputs, dropdown selectors, and context pickers. Distinct from Panel Elevation through higher base brightness and crisp boundary definitions.
- **Crimson Proximity Glow**: Modals, focused prompt input fields, and streaming tokens receive a restrained focus aura: `0 0 0 1px #e11d48, 0 8px 24px -4px rgba(225, 29, 72, 0.18)`.

## Shapes

The interface embraces a refined, surgical geometry. A conservative soft corner radius (`roundedness: 1`) provides enough contour to prevent harsh industrial brutalism while avoiding frivolous curves. 

- **Standard Elements (inputs, buttons, cards)**: 4px (`0.25rem`) corner rounding.
- **Large Overlays & Bottom Drawers**: 8px (`0.5rem`) corner rounding.
- **System Tags & Pill Badges**: Strict 4px geometry or complete pill capsules (when displaying isolated execution statuses or model version stamps).

## Components

### Buttons
- **Primary Execute**: Background `#e11d48`, text `#f4f4f5`, 4px radius, font `Inter` Medium 14px. On press/active: background `#991b1b`.
- **Secondary / Ghost**: Background `transparent`, border 1px solid `#27272a`, text `#f4f4f5`. Hover/Focus: border `#e11d48`, background `#121214`.
- **Destructive**: Background `#991b1b` at 20% opacity, border 1px solid `#ef4444`, text `#ef4444`.

### Chips & Model Badges
- Small metadata tags running `label-mono-tag`.
- Background `#18181b`, border 1px solid `#27272a`, text `#a1a1aa`.
- Active model indicator: 1px border `#e11d48`, text `#f4f4f5`, with a 4px solid `#e11d48` circular pulsing indicator.

### Input Fields & Prompt Console
- Floating mobile dock using `#121214` surface background, 1px solid border `#27272a`.
- Focus state: border `#e11d48` accompanied by the Crimson Proximity Glow.
- Typographic styling: `body-md` in `#f4f4f5` with placeholder text in `#52525b`. Monospace prompt variables rendered inline in `#e11d48`.

### Checkboxes, Switches & Radio Controls
- Custom micro-controls. Inactive: border 1px solid `#27272a`, background `#09090b`.
- Selected/Active: border `#e11d48`, background `#e11d48`, check/pip graphic `#f4f4f5`.

### Cards & Stream Threads
- Assistant turns: Background `#121214`, 1px solid `#27272a`, left-bordered with a 2px vertical ruby hairline indicator during real-time token streaming.
- User turns: Background `transparent`, border 1px solid `#18181b`, right-aligned.

### Latency & Token Counter (Domain Specific)
- Fixed or sticky mobile bottom rail component.
- Font: `JetBrains Mono` (`label-code-sm`).
- Displays context tokens (e.g., `3,412 / 8,192 tok`), execution latency (e.g., `42ms TTFT`), and cost in high-contrast crisp text `#a1a1aa` accented with `#e11d48`.